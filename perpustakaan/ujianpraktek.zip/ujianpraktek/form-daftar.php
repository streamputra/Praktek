<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Formulir Pendaftaran Siswa Baru | SMK Telkom</title>

    <style>
        body {
            background-image: url("https://www.itb.ac.id/files/dokumentasi/1645421808-teknologi-kuantum-freepik.jpg");
        }

        button {
            background-color: #6c5ce7;
            border-color: #a29bfe;
            border-radius: 5px;
            padding: 2.5px 2.5px 2.5px 2.5px;
        }
    </style>
</head>

    <body>
        <div class="container">

            <form action="proses-pendaftaran.php" method="POST">
                <table>
                    <tr>
                        <td>
                            <header>
                                <h3>Formulir Pendaftaran Siswa Baru</h3>
                            </header>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <br>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="nama">Nama : </label>
                        <input type="text" name="nama" placeholder="Masukkan Nama Lengkap Anda" style="width: 300px; border-radius: 5px; border-color: #a29bfe;" /></td>
                    </tr>
                    <tr>
                        <td><label for="jenis_kelamin">Jenis Kelamin : </label></td>
                    </tr>
                    <tr>
                        <td><label><input type="radio" name="jenis_kelamin" value="Laki-Laki" style="border-color: #a29bfe;"> Laki-laki</label>
                        <label><input type="radio" name="jenis_kelamin" value="Perempuan" style="border-color: #a29bfe;"> Perempuan</label></td>
                    </tr>
                    <tr>
                        <td><label for="agama">Agama : </label></td>
                    </tr>
                    <tr>
                        <td><select name="agama" style="border-radius: 5px; border-color: #a29bfe;">
                            <option>Islam</option>
                            <option>Kristen</option>
                            <option>Hindu</option>
                            <option>Budha</option>
                            <option>Konghucu</option>
                        </select></td>
                    </tr>
                    <tr>
                        <td><label for="alamat">Alamat : </label>
                        <textarea name="alamat" placeholder="Masukkan Alamat Anda" style="width: 300px; border-radius: 5px; border-color: #a29bfe;"></textarea></td>
                    </tr>
                    <tr>
                        <td><label for="asal_sekolah">Asal Sekolah : </label>
                        <input type="text" name="asal_sekolah" placeholder="Masukkan Asal Sekolah Anda" style="width: 300px; border-radius: 5px; border-color: #a29bfe;" /></td>
                    </tr>
                    <tr>
                        <td>
                            <br>
                        </td>
                    </tr>
                    <tr>
                        <td><input type="submit" value="Daftar" name="daftar" style="color: #fff; background-color: #6c5ce7; border-color: #a29bfe; border-radius: 5px; padding: 2.5px 2.5px 2.5px 2.5px;" /></td>
                    </tr>
                    <tr>
                        <td>
                            <br>
                        </td>
                    </tr>
                    <tr>
                        <td><p><button><a href="halaman-depan.php" style="color: #fff; text-decoration: none;">Kembali Ke Halaman Depan</a></button></p></td>
                    </tr>
                    <tr>
                        <td><p><button><a href="list-siswa.php" style="color: #fff; text-decoration: none;">Menuju Ke Halaman Data Pendaftar</a></button></p></td>
                    </tr>
                </table>   
            </form>

        </div>
    </body>
</html>